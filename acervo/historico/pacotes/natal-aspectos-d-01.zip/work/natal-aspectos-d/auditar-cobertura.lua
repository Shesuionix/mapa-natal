token = {set_macro=function() end}
texio = {write_nl=function(_,value) if value:find("[Cobertura]",1,true) then print(value) end end}
dofile("dados-relatorio.lua")