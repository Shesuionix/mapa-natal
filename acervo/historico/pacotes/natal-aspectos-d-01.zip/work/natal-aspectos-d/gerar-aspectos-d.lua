local read = dofile("entrada.lua").read
local index = 151
for _, id in ipairs({"d"}) do
  local data = read("../mapas-bc/mapa-" .. id .. ".txt")
  local positions = {}
  for _, p in ipairs(data.positions) do
    positions[p.name] = table.concat({p.name,p.sign,p.house,tostring(p.retrograde)}, "|")
  end
  for name, cusp in pairs(data.angles) do positions[name] = cusp.sign end
  for _, a in ipairs(data.aspects) do
    local first, second = a.first, a.second
    if second < first then first, second = second, first end
    index = index + 1
    print(("  [%q] = %d,"):format(table.concat({first,a.kind,second,positions[first],positions[second]}, ":"), index))
  end
end