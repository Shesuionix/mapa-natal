local ok,m=pcall(require,"sha2"); print(ok); if ok then for k in pairs(m) do print(k) end end
