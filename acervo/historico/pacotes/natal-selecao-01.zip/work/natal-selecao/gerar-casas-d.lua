local reader = dofile("entrada.lua")
local rulers = {Aries="Mars", Taurus="Venus", Gemini="Mercury", Cancer="Moon", Leo="Sun",
  Virgo="Mercury", Libra="Venus", Scorpio="Mars", Sagittarius="Jupiter",
  Capricorn="Saturn", Aquarius="Saturn", Pisces="Jupiter"}
local index = 36
for _, id in ipairs({"d"}) do
  local chart = reader.read("../mapas-bc/mapa-" .. id .. ".txt")
  local keys, houses = {}, {}
  for h=1,12 do houses[h] = {} end
  for _, p in ipairs(chart.positions) do
    local key = table.concat({p.name,p.sign,p.house,tostring(p.retrograde)}, "|")
    keys[p.name] = key
    table.insert(houses[p.house],key)
  end
  for h,cusp in ipairs(chart.cusps) do
    index = index + 1
    local ruler = rulers[cusp.sign]
    print(("  {%d, %d, %q, %q, %q, %q},"):format(index,h,cusp.sign,table.concat(houses[h],";"),ruler,keys[ruler]))
  end
end