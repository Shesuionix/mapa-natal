local reader = dofile("entrada.lua")
local texts = dofile("leitura-composta.lua")
local chart = reader.read("exemplo.txt")
local signs={"Aries","Taurus","Gemini","Cancer","Leo","Virgo","Libra","Scorpio","Sagittarius","Capricorn","Aquarius","Pisces"}
local locations, points, names = {}, {}, {}
local counts = {0,0,0,0}
for _, body in ipairs(chart.positions) do
  locations[body.name] = body
  names[body.name] = body.name
  points[#points+1] = body.name
  for _, sign in ipairs(signs) do
    for house=1,12 do
      for _, retrograde in ipairs({false,true}) do
        assert(#texts.position({name=body.name, sign=sign, house=house, retrograde=retrograde}) > 0)
        counts[1] = counts[1]+1
      end
    end
  end
end
for name, cusp in pairs(chart.angles) do locations[name]=cusp; points[#points+1]=name end
for _, axis in ipairs({{"Ascendant","DSC"},{"MC","IC"}}) do
  for i,sign in ipairs(signs) do
    assert(#texts.axis(axis[1],{sign=sign},axis[2],{sign=signs[(i+5)%12+1]},1)>0)
    counts[2] = counts[2]+1
  end
end
for house=1,12 do
  local saved=chart.cusps[house].sign
  for _, sign in ipairs(signs) do
    chart.cusps[house].sign=sign
    assert(#texts.house(chart,house,names)>0)
    counts[3]=counts[3]+1
  end
  chart.cusps[house].sign=saved
end
for i, first in ipairs(points) do
  for j=i+1,#points do
    for _, kind in ipairs({"Conjunction","Sextile","Square","Trine","Opposition"}) do
      assert(#texts.aspect({first=first,second=points[j],kind=kind},locations)>0)
      counts[4]=counts[4]+1
    end
  end
end
print(table.concat(counts,", "))
assert(table.concat(counts,",")=="4320,24,144,855")