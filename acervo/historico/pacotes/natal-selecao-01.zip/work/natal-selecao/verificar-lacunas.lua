token = {set_macro=function() end}
texio = {write_nl=function(_,line) if line:find("[Lacuna editorial]",1,true) then print(line) end end}
dofile("dados-relatorio.lua")