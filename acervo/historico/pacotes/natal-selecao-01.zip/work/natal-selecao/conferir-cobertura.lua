local wanted = {NatalTotalLeituras=true,NatalTotalEixos=true,NatalTotalCasas=true,NatalTotalAspectos=true}
token = {set_macro = function(name, value) if wanted[name] then print(name, value) end end}
texio = {write_nl = function() end}
dofile("dados-relatorio.lua")