local reader=dofile('entrada.lua')
local c=dofile('catalogo-editorial.lua')
local reviewed=reader.read('mapa-editorial-v1.txt')
local pLib,hLib,aLib=c.positions(reviewed),c.houses(reviewed),c.aspects(reviewed)
local data=reader.read(arg[1])
local p,o,a=c.facts(data)
local id=138
for _, position in ipairs(data.positions) do
  local key=c.position_key(position)
  if not pLib[key] then id=id+1;print('P',id,key) end
end
id=119
for n=1,12 do
  local i,key=c.select_house(n,data,p,o,a,hLib)
  if not i then id=id+1;print('H',id,key) else print('H existente',i,n) end
end
id=470
for _, asp in ipairs(data.aspects) do
  local key=c.contextual_aspect_key(asp,p)
  if not aLib[key] then id=id+1;print('A',id,key,asp.orb,asp.phase) end
end