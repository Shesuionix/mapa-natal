local macros = {}
token = {set_macro=function(name, value) macros[name]=value end}
texio = {write_nl=function(_,value) print(value) end}
dofile("dados-relatorio.lua")
local mode = arg[1]
if mode == "explicito" then
  assert(macros.NatalPosicoes:match("Netuno & Escorpião.- & 5 & E"))
  assert(macros.NatalVelocidades:match("Netuno & .- & Estacionário & Stationary"))
  assert(macros.NatalLeiturasSelecionadas:find("\\NatalLeituraPosicao{61}{Netuno}",1,true))
  assert(macros.NatalLeiturasCasas:find("\\NatalLeituraCasa{49}{Escorpião}",1,true))
elseif mode == "zero" then
  assert(macros.NatalPosicoes:match("Netuno & Escorpião.- & 5 & E") == nil)
  assert(macros.NatalVelocidades:match("Netuno & .- & Indefinida & Slow"))
end
print("Verificação: " .. mode)