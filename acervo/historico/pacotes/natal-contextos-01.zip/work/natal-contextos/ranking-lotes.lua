local reader=dofile('entrada.lua')
local c=dofile('catalogo-editorial.lua')
local reviewed=reader.read('mapa-editorial-v1.txt')
local pos, houses, aspects=c.positions(reviewed),c.houses(reviewed),c.aspects(reviewed)
for _, path in ipairs(arg) do
  local chart=reader.read(path)
  local p,o,a=c.facts(chart)
  local np,nh,na=0,0,0
  for _, v in ipairs(chart.positions) do if not pos[c.position_key(v)] then np=np+1 end end
  for n=1,12 do if not c.select_house(n,chart,p,o,a,houses) then nh=nh+1 end end
  for _, v in ipairs(chart.aspects) do if not aspects[c.contextual_aspect_key(v,p)] then na=na+1 end end
  print(path:match('[^/\\]+$'), np, nh, na, np+nh+na, #chart.warnings)
end