local chart=dofile('entrada.lua').read(arg[1])
local c=dofile('catalogo-editorial.lua')
local a=dofile('entrada.lua').read('mapa-editorial-v1.txt')
local p,o,s=c.facts(chart)
local h=c.houses(a)
local ap=c.aspects(a)
for i,v in ipairs(chart.positions) do
  local k=c.position_key(v)
  if not c.positions(a)[k] then print('P', i+60-(i>9 and 1 or 0), k) end
end
for i=1,12 do local id,key=c.select_house(i,chart,p,o,s,h); if not id then print('H',i,key) end end
for i,v in ipairs(chart.aspects) do local k=c.contextual_aspect_key(v,p); assert(not ap[k]); print('A',i+202,k) end