local reader=dofile('entrada.lua')
local catalog=dofile('catalogo-editorial.lua')
local reviewed=reader.read('mapa-editorial-v1.txt')
local library=catalog.positions(reviewed)
local evidence={}
local file=assert(io.open(arg[1], 'r'))
for line in file:lines() do evidence[line:match('^[^\t]+')] = true end
file:close()
local count=0
for key, id in pairs(library) do
  if id >= 177 and id <= 195 then
    assert(evidence[key], 'Sem evidencia: '..key)
    assert(key:match('^Sun|') and (key:match('|1|false$') or key:match('|11|false$')),key)
    count=count+1
  end
end
assert(count==19, count)
local macros={}
token={set_macro=function(name,value) macros[name]=value end}
texio={write_nl=function()end}
dofile('dados-relatorio.lua')
local chart=reader.read(os.getenv('NATAL_ENTRADA'))
local key=catalog.position_key(chart.positions[1])
local id=assert(library[key],key)
assert(id>=177 and id<=195)
assert(macros.NatalLeiturasSelecionadas:find('\\NatalLeituraPosicao{'..id..'}{Sol}',1,true),key)
print(key, id)